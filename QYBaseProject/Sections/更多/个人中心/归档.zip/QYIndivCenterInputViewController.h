//
//  QYIndivCenterInputViewController.h
//  QYBaseProject
//
//  Created by 田 on 15/6/9.
//  Copyright (c) 2015年 田. All rights reserved.
//

#import "QYSuperclassViewController.h"

@interface QYIndivCenterInputViewController : QYSuperclassViewController
@property(nonatomic,copy)void(^completBlock)(NSString *string);

@end
