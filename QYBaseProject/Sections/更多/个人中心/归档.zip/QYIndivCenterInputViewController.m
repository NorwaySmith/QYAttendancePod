//
//  QYIndivCenterInputViewController.m
//  QYBaseProject
//
//  Created by 田 on 15/6/9.
//  Copyright (c) 2015年 田. All rights reserved.
//

#import "QYIndivCenterInputViewController.h"
#import "QYTheme.h"
#import "Masonry.h"
#import "NSString+ToolExtend.h"
@interface QYIndivCenterInputViewController ()
@property(strong,nonatomic)UITextView *textView;
@property(strong,nonatomic)UIImageView *lineImageView;

@end

@implementation QYIndivCenterInputViewController
#pragma mark - life cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self registerForKeyboardNotifications];
    [self setupUI];
    [self setupRightBarButton];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - event response
-(void)done{
     NSString *text = [_textView.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    if ([text isNil]) {

        return;
    }
    if (_completBlock) {
        _completBlock(_textView.text);
    }
}
#pragma mark - private methods
-(void)setupRightBarButton{
    UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    rightButton.titleLabel.font = [UIFont systemFontOfSize:15];
    [rightButton setTitle:@"完成" forState:UIControlStateNormal];
    [rightButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [rightButton addTarget:self action:@selector(done) forControlEvents:UIControlEventTouchUpInside];
    rightButton.frame = CGRectMake(0, 0, 50, 44);
    rightButton.titleLabel.font = [UIFont systemFontOfSize:15];
    UIBarButtonItem *operationBar=[[UIBarButtonItem alloc]initWithCustomView:rightButton];
    UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc]
                                       initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                       target:nil action:nil];
    negativeSpacer.width = -15;
     self.navigationItem.rightBarButtonItems=@[negativeSpacer, operationBar];
}
-(void)setupUI{
    self.textView = [[UITextView alloc] init];
    _textView.font = [UIFont systemFontOfSize:17];
    _textView.backgroundColor=[UIColor clearColor];
    _textView.scrollEnabled=NO;
    [self.view addSubview:_textView];
    
    self.lineImageView = [[UIImageView alloc] init];
    _lineImageView.backgroundColor = [UIColor purpleColor];
    [self.view addSubview:_lineImageView];
    
    [_textView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(@(padding));
        make.left.equalTo(@(padding));
        make.right.equalTo(@(-padding));
        make.height.equalTo(@(37));
    }];
    
    [_lineImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_textView.mas_baseline);
        make.left.equalTo(@(padding));
        make.right.equalTo(@(-padding));
        make.height.equalTo(@(1));
    }];

}


#pragma mark - CustomDelegate
//-(void)textViewDidChange:(UITextView *)textView
//{
//    CGRect bounds = textView.bounds;
//    
//    // 计算 text view 的高度
//    CGSize maxSize = CGSizeMake(bounds.size.width, CGFLOAT_MAX);
//    CGSize newSize = [textView sizeThatFits:maxSize];
//    bounds.size = newSize;
//    
//    textView.bounds = bounds;
//    
//}
- (void) registerForKeyboardNotifications
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardDidShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter]  addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardDidHideNotification object:nil];
}

- (void) keyboardWasShown:(NSNotification *) notif
{
    NSDictionary *info = [notif userInfo];
    NSValue *value = [info objectForKey:UIKeyboardFrameBeginUserInfoKey];
    CGSize keyboardSize = [value CGRectValue].size;
    
    NSLog(@"keyBoard:%f", keyboardSize.height);  //216
    ///keyboardWasShown = YES;
    CGFloat height=self.view.frame.size.height-keyboardSize.height-padding*2-64;
    [_textView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.height.equalTo(@(height));
    }];
}
- (void) keyboardWasHidden:(NSNotification *) notif
{
    NSDictionary *info = [notif userInfo];
    
    NSValue *value = [info objectForKey:UIKeyboardFrameBeginUserInfoKey];
    CGSize keyboardSize = [value CGRectValue].size;
    NSLog(@"keyboardWasHidden keyBoard:%f", keyboardSize.height);
    // keyboardWasShown = NO;
    CGFloat height=self.view.frame.size.height-keyboardSize.height-padding*2-64;
    [_textView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.height.equalTo(@(height));
    }];
}


@end
